#ifndef __STRUCT_EXTERN_H__
#define __STRUCT_EXTERN_H__

//所有的对外结构都在这里
#include "1_driver/driver.h"
#include "2_engine/engine_struct.h"
#include "3_display/display_struct.h"

#endif