#ifndef __PRIVATE_IMAGE_H__
#define __PRIVATE_IMAGE_H__

//这个文件用来声明内置图像
typedef struct image_t image;

extern image mystery_chinese_word_loading;

#endif