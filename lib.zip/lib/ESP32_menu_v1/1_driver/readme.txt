

1_driver  负责提供驱动硬件的API

本层对外功能模块如下
  keyboard:提供键盘扫描函数（可自定义）
  函数 
    get_key_value
    get_last_key
    get_press_time