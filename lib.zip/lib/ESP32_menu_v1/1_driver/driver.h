#ifndef __DRIVER_H___
#define __DRIVER_H___

#include "1_driver/keyboard/keyboard.h"

//该层初始化清单
#define INIT_LIST_1 \
    keyboard_init();

#endif