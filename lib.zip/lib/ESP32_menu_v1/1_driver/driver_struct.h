#ifndef __DRIVER_STRUCT_H__
#define __DRIVER_STRUCT_H__

#include "1_driver/keyboard/keyboard_struct.h"

#endif