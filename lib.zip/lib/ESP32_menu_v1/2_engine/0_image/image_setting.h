#ifndef __IMAGE_SETTING_H__
#define __IMAGE_SETTING_H__

#include "0_config/config.h"

#endif