#ifndef __LIST_H__
#define __LIST_H__

#include "list_struct.h"
#include "list_macro.h"

bool set_list_cursor( list *LIST );

#endif