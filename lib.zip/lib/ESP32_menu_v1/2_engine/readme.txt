

2_engine  负责处理逻辑，把输入转化成数据

本层对外功能模块如下
  0_image:提供了简单的处理图像的函数
  函数
    set_black_image_background  
    rotate_image

  0_list:提供了处理列表逻辑的简单函数
  函数
    set_list_cursor

  0_menu:提供了处理菜单逻辑的简单函数
  函数
    set_menu_cursor

  0_setting:提供了处理设置逻辑的简单函数
  函数
    set_int_setting
    set_char_setting
    set_float_setting
  