#ifndef __MENU_H__
#define __MENU_H__

//结构定义
#include "menu_struct.h"
//宏定义
#include "menu_macro.h"

//这个模块包含了菜单列表对外的函数接口

//对外声明函数
bool set_menu_cursor( menu *MENU );

#endif

