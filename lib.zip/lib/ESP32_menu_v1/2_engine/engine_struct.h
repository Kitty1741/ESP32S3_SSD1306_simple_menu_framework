#ifndef __ENGINE_STRUCT__
#define __ENGINE_STRUCT__

#include "2_engine/0_image/image_struct.h"
#include "2_engine/0_list/list_struct.h"
#include "2_engine/0_menu/menu_struct.h"
#include "2_engine/0_setting/setting_struct.h"

#endif