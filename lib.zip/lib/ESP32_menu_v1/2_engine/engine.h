#ifndef __ENGINE___
#define __ENGINE___

#include "2_engine/0_menu/menu.h"
#include "2_engine/0_list/list.h"
#include "2_engine/0_image/image.h"
#include "2_engine/0_setting/setting.h"

//该层初始化清单
#define INIT_LIST_2 \

    ;

#endif