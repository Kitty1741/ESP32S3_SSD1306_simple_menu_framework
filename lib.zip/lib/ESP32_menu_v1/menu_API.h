#ifndef __MENU_API_H__
#define __MENU_API_H__

//对外接口

//里面有所有涉及的结构
#include "4_API/API_struct.h"

//里面有所有涉及的对外函数
#include "4_API/API.h"


#endif